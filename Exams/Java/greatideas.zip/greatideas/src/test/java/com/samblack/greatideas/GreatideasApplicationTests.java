package com.samblack.greatideas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreatideasApplicationTests {

	@Test
	void contextLoads() {
	}

}
