import React from 'react';
import logo from './logo.svg';
import './App.css';
import Task from './components/ToDo'

function App() {
  return (
    <div className="App">
     <Task />
    </div>
  );
}

export default App;
