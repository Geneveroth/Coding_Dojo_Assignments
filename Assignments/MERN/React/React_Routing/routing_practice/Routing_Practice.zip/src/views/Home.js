import React from 'react';

const Home =(props)=>{
    return (
        <div>
            <p>Welcome</p>
        </div>
    )
}

export default Home;