import React from 'react'

const Error=()=>{
    return(
        <>
        <h1>These are not the droids you are looking for.</h1>
        <img src="https://lumiere-a.akamaihd.net/v1/images/Obi-Wan-Kenobi_6d775533.jpeg?region=0%2C48%2C1536%2C768"/>
        </>
    )
}
export default Error;