import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1> Hello Dojo </h1>
      <ul> Things to Do:
          <li> Pass MERN</li>
          <li> Create Portfolio</li>
          <li> Get a Job!</li>
      </ul>
    </div>
  );
}

export default App;
