import React from 'react';
import Create from './Create';
import All from './All';
export default () => {
    return (
        <div>
           <Create/>
           <All/>
        </div>
    )
}
