import React from 'react';
import {Router} from '@reach/router';
import ProductForm from '../components/ProductForm';
import ProductList from '../components/ProductList';
import Details from '../views/Details'
export default () => {
    return (
        <div>
           <ProductForm/>
           <ProductList/>
        </div>
    )
}
