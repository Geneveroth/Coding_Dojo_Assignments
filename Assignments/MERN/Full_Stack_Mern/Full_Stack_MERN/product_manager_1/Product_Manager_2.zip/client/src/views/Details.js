import React, { useState, useEffect } from 'react'
import axios from 'axios';

export default (props) => {
const {id}=props; 
const [details, setDetails] = useState([]); 
const [hasError, setHasError] = useState(false);

useEffect(() => {
    axios.get('http://localhost:8000/api/product/'+ id)
      .then(res => setDetails({...res.data}))
      .catch(() => setHasError(true));
     }, [id]);
    if(hasError) return 'Something went wrong in details!';

    if(details === null) return 'Loading...';
    return(
        <div>
            <h1>{details.title}</h1>
            <p>{details.price}</p> 
            <p>{details.description}</p> 
        </div>
    )
}
