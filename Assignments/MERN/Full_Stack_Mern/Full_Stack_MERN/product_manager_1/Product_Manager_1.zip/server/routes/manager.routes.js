const ManagerController = require('../controllers/manager.controller');
module.exports = function(app){
    app.post('/api/product', ManagerController.createProduct);
    app.get('/api/product', ManagerController.getAllProducts);
}
