const { Manager } = require('../models/manager.model');
module.exports.createProduct = (req, res) => {
    const { title, price, description } = req.body;
    Manager.create({
        title,
        price,
        description
    })
        .then(product => res.json(product))
        .catch(err => res.json(err));
};
module.exports.getAllProducts=(req,res)=>{
    Manager.find()
    .then(allProducts=>res.json(allProducts))//should this be manager:allProducts? matches model.manager
    .catch(err => res.json(err));                       //might fix undefined error in postman
};
