package com.samblack.mvc.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.samblack.mvc.models.Book;
@Repository
public interface BookRepository extends CrudRepository<Book, Long>{//Book is class name, Long is primary key type
  
    List<Book> findAll();  
    Optional<Book> findById(Long id);
    void deleteById(Long id);
    
}
