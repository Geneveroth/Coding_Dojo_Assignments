package com.samblack.pathrise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PathriseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PathriseApplication.class, args);
	}

}
