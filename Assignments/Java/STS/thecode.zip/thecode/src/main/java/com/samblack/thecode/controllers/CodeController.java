package com.samblack.thecode.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class CodeController {
	@RequestMapping(value="/", method=RequestMethod.POST)
	public String formPage(@RequestParam(value="code") String code, HttpSession session){
		session.setAttribute("code", code);
		session.getAttribute("code");
		if(session.getAttribute(code)== "bushido") {
			return "code.jsp";
		}
		else return "index.jsp";
	}
	@RequestMapping("/error")
	public String flashError(RedirectAttributes redirectAttributes) {
		redirectAttributes.addFlashAttribute("error", "You Must Train Harder!");
		return "redirect:/";
	}
	
}
