package com.zookeeper;

public class BatTest {

	public static void main(String[] args) {
		Bat b=new Bat(300);
		b.attackTown();
		b.attackTown();
		b.attackTown();
		b.eatHumans();
		b.eatHumans();
		b.fly();
	}

}
