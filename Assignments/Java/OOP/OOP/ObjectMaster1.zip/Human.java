package com.objectmaster;

public class Human {
	protected String name;
	protected int strength=3;
	protected int stealth=3;
	protected int intelligence=3;
	protected int health=100;
	
	public Human(String name) {
		this.name=name;
	}
	public int attack(Human enemy) {
		enemy.health-=this.strength;
		System.out.println(enemy.name+" is hit for "+this.strength+" points of damage. Enemy health remaining: "+enemy.health);
		return enemy.health;
	}
}