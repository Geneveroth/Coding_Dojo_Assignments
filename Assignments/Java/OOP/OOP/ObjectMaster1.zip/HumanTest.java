package com.objectmaster;

public class HumanTest {

	public static void main(String[] args) {
		Human h =new Human("bob");
		Human enemy=new Human("Bad Guy");
		h.attack(enemy);
	}

}
