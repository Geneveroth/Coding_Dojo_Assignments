import java.util.*;
public class Portfolio {
	private ArrayList<Project> projects=new ArrayList<Project>();
}
