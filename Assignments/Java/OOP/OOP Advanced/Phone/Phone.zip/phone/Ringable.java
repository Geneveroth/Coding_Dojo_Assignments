package com.phone;

public interface Ringable {
	String ring();
	String unlock();
}
