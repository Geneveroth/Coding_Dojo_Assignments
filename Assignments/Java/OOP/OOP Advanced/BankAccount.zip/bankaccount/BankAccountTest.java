package com.bankaccount;

public class BankAccountTest {

	public static void main(String[] args) {
		BankAccount acct=new BankAccount();
		acct.getNumberOfAccounts();
		acct.depositChecking(500);
		acct.getCheckingBalance();
		acct.depositSavings(300);
		acct.getSavingsBalance();
		acct.withdrawChecking(200);
		acct.getCheckingBalance();
		acct.withdrawSavings(100);
		acct.getSavingsBalance();
		acct.withdrawChecking(600);
		acct.total();

	}

}
