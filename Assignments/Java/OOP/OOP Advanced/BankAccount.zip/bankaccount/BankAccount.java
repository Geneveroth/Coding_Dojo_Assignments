package com.bankaccount;
import java.util.*;

public class BankAccount {
	private String accountNumber;
	private double checkingBalance=0;
	private double savingsBalance=0;
	private static int numberOfAccounts=0;
	private static double totalBalance=0;

	public BankAccount () {
		accountNumber=newAccount();
		numberOfAccounts++;
	}
	public int getNumberOfAccounts() {
		System.out.println("There are "+numberOfAccounts+" accounts.");
		return numberOfAccounts;
	}
	public double getCheckingBalance() {
		System.out.println("Your Checking has an available balance of "+checkingBalance+".");
		return checkingBalance;
	}
	public void setCheckingBalance(double checkingBalance) {
		this.checkingBalance = checkingBalance;
	}
	public double getSavingsBalance() {
		System.out.println("Your Savings has an available balance of "+savingsBalance+".");
		return savingsBalance;
	}
	public void setSavingsBalance(double savingsBalance) {
		this.savingsBalance = savingsBalance;
	}
	private String newAccount() {
        String number = "";
        Random random = new Random();
        for(int i = 0; i<10; i++) {
            number += random.nextInt(10);
        }
        return number;
    }
	public double depositChecking(double amount) {
			setCheckingBalance(checkingBalance+amount);
			totalBalance+=checkingBalance;
			System.out.println("You deposited "+amount+" into your Checking Account.");
			return checkingBalance;
		}
	public double depositSavings(double amount) {
			setSavingsBalance(savingsBalance+amount);
			totalBalance+=savingsBalance;
			System.out.println("You deposited "+amount+" into your Savings Account.");
			return savingsBalance;
		}
	public void withdrawChecking(double amount) {
		if(checkingBalance<amount) {
			System.out.println("Cannot withdraw without a positive balance.");
			
		}
		else{
			setCheckingBalance(checkingBalance-amount);
			System.out.println("You withdrew "+amount+" from your Checking Account.");
		}
		
		
	}
	public double withdrawSavings(double amount) {
		if(savingsBalance<amount) {
			System.out.println("Cannot withdraw without a positive balance.");
			return checkingBalance;
		}
		setCheckingBalance(savingsBalance-amount);
		System.out.println("You withdrew "+amount+" from your Savings Account.");
		return savingsBalance;
		
	}
	public double total() {
		System.out.println("You have a total available balance of "+totalBalance+".");
		return totalBalance;
	}
}
