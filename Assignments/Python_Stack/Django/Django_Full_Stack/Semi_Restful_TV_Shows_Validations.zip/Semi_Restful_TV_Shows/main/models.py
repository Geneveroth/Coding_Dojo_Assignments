from django.db import models

class ShowsManager(models.Manager):
    # def (can be named anything) takes the arguments of self, postData [might be able to name it differently, will check and come back.]
    def validation(self, postData):
        # errors is an empty {}
        errors = {}
        
        # conditions for the user's input
        # the key we are creating should match across the app of what we want to validate. IF NOT, we would need to create an IF STATEMENT for that particular POST DATA ["KEY"] coming in.
        if len(postData["show_title"]) < 2:
            errors["show_title"] = "Title name needs to be at least 2 characters long."

        if len(postData["show_network"]) < 3:
            errors["show_network"] = "Network name needs to be at least 3 characters long."

        if len(postData["show_description"]) < 10:
            errors["show_description"] = "Description needs to be at least 10 characters long."

        return errors

#******************************************************


class Shows(models.Model):
    show_title = models.CharField(max_length=45)
    show_network = models.CharField(max_length=45)
    show_date = models.DateField()
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
# we are going to override the objects property and have it reference our newly created manager, like so:
    objects = ShowsManager()