from django.shortcuts import render, redirect, HttpResponse
# must import messages from django.contrib so we have access to messages function
from django.contrib import messages
# must import models from main.models (you can use * to bring all in as well!)
from main.models import Shows

def shows(request):
    context={
        'shows': Shows.objects.all()
    }
    return render (request,'shows.html', context)

def newshow_page(request):
    return render (request, 'new.html')

def create_show (request):
    # add your validations by attaching them to a variable.
    errors = Shows.objects.validation(request.POST)
    # if the errors dictionary contains anything, loop through each key-value pair and make a flash message 
    if len(errors) > 0:
        for key, value in errors.items():
            #makes the flash message
            messages.error(request,value)
            # redirect the user back to the form to fix the errors
        return redirect(request.META.get("HTTP_REFERER"))
     #if the if statement is false, you don't have any errors and it posts to the form as normal
        created_show = Shows.objects.create(
            show_title = request.POST['show_title'],
            show_network = request.POST['show_network'],
            show_date = request.POST['show_date'],
            description = request.POST['show_description'],
        ) 
    forurl = created_show.id
    # going to redirect to page for the specific show
    return redirect(f'/shows/{forurl}')

def display_show (request, forurl):
    # print(forurl)
    context = {
        'displayed_show': Shows.objects.get(id = forurl)
    }
    #going to render the page for the specific show, tied to the "show" button on root and create button on new 
    return render(request, 'info.html', context)

def edit_show (request, forurl):
    # print(forurl)
    context = {
        'displayed_show': Shows.objects.get(id = forurl)
    }
    return render(request, 'edit_show.html', context)

def update_show (request, forurl):
    errors = Shows.objects.validation(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request,value)
        return redirect(request.META.get("HTTP_REFERER"))

    else:
        showtoupdate = Shows.objects.get(id = forurl)
        showtoupdate.show_title = request.POST['show_title']
        showtoupdate.show_network = request.POST['show_network']
        showtoupdate.show_date = request.POST['edit_date']
        showtoupdate.description = request.POST['show_description']
        showtoupdate.save()
    return redirect(f'/shows/{forurl}')

def delete_show (request, forurl):
    showtoupdate = Shows.objects.get(id = forurl)
    showtoupdate.delete()
    return redirect('/')