from django.apps import AppConfig


class MainIndexConfig(AppConfig):
    name = 'main_index'
